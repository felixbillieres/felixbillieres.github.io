<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TruthSeeker - Independent Investigative Journalism</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Special+Elite&family=Rajdhani:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Rajdhani', sans-serif;
            line-height: 1.6;
            color: #e0e0e0;
            background-color: #121212;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(37, 206, 116, 0.05) 0%, transparent 70%),
                url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23203354' fill-opacity='0.1'%3E%3Cpath d='M50 50c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10s-10-4.477-10-10 4.477-10 10-10zM10 10c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10S0 25.523 0 20s4.477-10 10-10zm10 8c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm40 40c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
        .navbar {
            background-color: #1a1a2e;
            border-bottom: 1px solid #31e884;
            box-shadow: 0 2px 20px rgba(49, 232, 132, 0.2);
        }
        .navbar-brand {
            font-weight: bold;
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 1px;
            text-shadow: 0 0 5px rgba(49, 232, 132, 0.7);
            color: #31e884 !important;
        }
        .jumbotron {
            background-color: rgba(20, 20, 36, 0.8);
            border: 1px solid rgba(49, 232, 132, 0.3);
            padding: 4rem 2rem;
            border-radius: 15px;
            backdrop-filter: blur(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        .jumbotron h1 {
            font-family: 'Special Elite', cursive;
            color: #31e884;
            text-shadow: 0 0 10px rgba(49, 232, 132, 0.5);
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.4);
            background-color: rgba(30, 30, 46, 0.8);
            border: 1px solid rgba(49, 232, 132, 0.2);
            transition: all 0.3s ease;
            border-radius: 10px;
            overflow: hidden;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(49, 232, 132, 0.2);
            border-color: rgba(49, 232, 132, 0.5);
        }
        .card-title {
            color: #31e884;
            font-family: 'Orbitron', sans-serif;
        }
        .btn-primary, .btn-outline-primary {
            background-color: #1a1a2e;
            border-color: #31e884;
            color: #31e884;
            transition: all 0.3s ease;
        }
        .btn-primary:hover, .btn-outline-primary:hover {
            background-color: #31e884;
            color: #1a1a2e;
            box-shadow: 0 0 15px rgba(49, 232, 132, 0.5);
        }
        .btn-outline-primary {
            background-color: transparent;
        }
        .nav-link {
            position: relative;
            color: #e0e0e0 !important;
            transition: all 0.3s ease;
        }
        .nav-link:hover, .nav-link.active {
            color: #31e884 !important;
        }
        .nav-link:before {
            content: "";
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #31e884;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        .nav-link:hover:before, .nav-link.active:before {
            visibility: visible;
            width: 100%;
        }
        .footer {
            background-color: #1a1a2e;
            border-top: 1px solid #31e884;
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
            box-shadow: 0 -2px 20px rgba(49, 232, 132, 0.2);
        }
        .truth-symbol {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 100px;
            height: 100px;
            opacity: 0.2;
            z-index: 0;
        }
        .truth-symbol:before, .truth-symbol:after {
            content: "";
            position: absolute;
            background-color: #31e884;
        }
        .truth-symbol:before {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            top: 20px;
            left: 20px;
            box-shadow: 0 0 20px #31e884;
        }
        .truth-symbol:after {
            width: 80px;
            height: 2px;
            top: 50px;
            left: 10px;
            box-shadow: 0 0 10px #31e884;
            transform: rotate(45deg);
        }
        @keyframes glow {
            0% { text-shadow: 0 0 5px rgba(49, 232, 132, 0.7); }
            50% { text-shadow: 0 0 20px rgba(49, 232, 132, 1); }
            100% { text-shadow: 0 0 5px rgba(49, 232, 132, 0.7); }
        }
        .navbar-brand {
            animation: glow 2s infinite;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="/">TruthSeeker</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/articles">Articles</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/submit-theory">Submit Theory</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="jumbotron">
        <div class="container">
            <h1 class="display-4">Uncovering the Truth</h1>
            <p class="lead">TruthSeeker is an independent platform dedicated to investigative journalism and whistleblower protection.</p>
            <hr class="my-4">
            <p>Do you have information the public needs to know? Our secure platform ensures your identity is protected.</p>
            <a class="btn btn-primary btn-lg" href="/submit-theory" role="button">Submit Your Theory</a>
        </div>
    </div>

    <!-- Content -->
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h2 class="mb-4">Recent Investigations</h2>
                <div class="card mb-4">
                    <div class="card-body">
                        <h3 class="card-title">Classified Documents Reveal Unauthorized Surveillance Program</h3>
                        <p class="card-text">A whistleblower has provided evidence of a massive surveillance operation targeting civilians without judicial oversight.</p>
                        <p><small class="text-muted">Posted on September 12, 2023</small></p>
                        <a href="/articles" class="btn btn-outline-primary">Read More</a>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-body">
                        <h3 class="card-title">Corporate Cover-up: Environmental Damage Concealed for Decades</h3>
                        <p class="card-text">Internal memos show that executives were aware of the environmental impact but chose to hide the findings from regulators.</p>
                        <p><small class="text-muted">Posted on August 28, 2023</small></p>
                        <a href="/articles" class="btn btn-outline-primary">Read More</a>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title">Government Contracts: The Hidden Money Trail</h3>
                        <p class="card-text">An investigation into government contracts reveals concerning patterns of awards to companies with political connections.</p>
                        <p><small class="text-muted">Posted on August 15, 2023</small></p>
                        <a href="/articles" class="btn btn-outline-primary">Read More</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <h2 class="mb-4">Why TruthSeeker?</h2>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Secure Publishing</h5>
                        <p class="card-text">Our platform uses advanced technology to protect your identity and ensure your revelations reach the public.</p>
                    </div>
                </div>
                
                <div class="card mt-4">
                    <div class="card-body">
                        <h5 class="card-title">XML Transformation</h5>
                        <p class="card-text">We use XSLT technology to transform your structured data into readable and shareable content, protecting the integrity of your information.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>TruthSeeker</h3>
                    <p>Independent Investigative Journalism</p>
                </div>
                <div class="col-md-6 text-md-right">
                <p>Server Side Training With Phreaks 2600- By <a href="https://felix-billieres.gitbook.io/v2" target="_blank" style="color: #31e884; text-decoration: underline;">Elliot Belt</a> </p>

                </div>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 