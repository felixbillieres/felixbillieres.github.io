<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Your Theory - TruthSeeker</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.62.0/codemirror.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Special+Elite&family=Rajdhani:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Rajdhani', sans-serif;
            line-height: 1.6;
            color: #e0e0e0;
            background-color: #121212;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(37, 206, 116, 0.05) 0%, transparent 70%),
                url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23203354' fill-opacity='0.1'%3E%3Cpath d='M50 50c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10s-10-4.477-10-10 4.477-10 10-10zM10 10c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10S0 25.523 0 20s4.477-10 10-10zm10 8c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm40 40c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
        .navbar {
            background-color: #1a1a2e;
            border-bottom: 1px solid #31e884;
            box-shadow: 0 2px 20px rgba(49, 232, 132, 0.2);
        }
        .navbar-brand {
            font-weight: bold;
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 1px;
            text-shadow: 0 0 5px rgba(49, 232, 132, 0.7);
            color: #31e884 !important;
        }
        .editor-container {
            margin-bottom: 30px;
        }
        .CodeMirror {
            height: 300px;
            border: 1px solid rgba(49, 232, 132, 0.3);
            background-color: rgba(20, 20, 36, 0.8);
            color: #e0e0e0;
            border-radius: 5px;
        }
        h1, h2, h3, h4, h5 {
            color: #31e884;
            font-family: 'Special Elite', cursive;
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.4);
            background-color: rgba(30, 30, 46, 0.8);
            border: 1px solid rgba(49, 232, 132, 0.2);
            transition: all 0.3s ease;
            border-radius: 10px;
            overflow: hidden;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(49, 232, 132, 0.2);
            border-color: rgba(49, 232, 132, 0.5);
        }
        .card-title {
            color: #31e884;
            font-family: 'Orbitron', sans-serif;
        }
        .btn-primary, .btn-outline-primary {
            background-color: #1a1a2e;
            border-color: #31e884;
            color: #31e884;
            transition: all 0.3s ease;
        }
        .btn-primary:hover, .btn-outline-primary:hover {
            background-color: #31e884;
            color: #1a1a2e;
            box-shadow: 0 0 15px rgba(49, 232, 132, 0.5);
        }
        .form-control {
            background-color: rgba(20, 20, 36, 0.8);
            border: 1px solid rgba(49, 232, 132, 0.3);
            color: #e0e0e0;
        }
        .nav-link {
            position: relative;
            color: #e0e0e0 !important;
            transition: all 0.3s ease;
        }
        .nav-link:hover, .nav-link.active {
            color: #31e884 !important;
        }
        .nav-link:before {
            content: "";
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #31e884;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        .nav-link:hover:before, .nav-link.active:before {
            visibility: visible;
            width: 100%;
        }
        .footer {
            background-color: #1a1a2e;
            border-top: 1px solid #31e884;
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
            box-shadow: 0 -2px 20px rgba(49, 232, 132, 0.2);
        }
        .truth-symbol {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 100px;
            height: 100px;
            opacity: 0.2;
            z-index: 0;
        }
        .truth-symbol:before, .truth-symbol:after {
            content: "";
            position: absolute;
            background-color: #31e884;
        }
        .truth-symbol:before {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            top: 20px;
            left: 20px;
            box-shadow: 0 0 20px #31e884;
        }
        .truth-symbol:after {
            width: 80px;
            height: 2px;
            top: 50px;
            left: 10px;
            box-shadow: 0 0 10px #31e884;
            transform: rotate(45deg);
        }
        @keyframes glow {
            0% { text-shadow: 0 0 5px rgba(49, 232, 132, 0.7); }
            50% { text-shadow: 0 0 20px rgba(49, 232, 132, 1); }
            100% { text-shadow: 0 0 5px rgba(49, 232, 132, 0.7); }
        }
        .navbar-brand {
            animation: glow 2s infinite;
        }
        code {
            background-color: rgba(49, 232, 132, 0.1);
            color: #31e884;
            border-radius: 3px;
            padding: 2px 5px;
        }
    </style>
</head>
<body>
    <div class="truth-symbol"></div>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="/">TruthSeeker</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/articles">Articles</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="/submit-theory">Submit Theory</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4">Submit Your Theory</h1>
        
        <?php foreach ($flash_messages as $message): ?>
            <div class="alert alert-<?php echo $message['type']; ?>">
                <?php echo $message['message']; ?>
            </div>
        <?php endforeach; ?>
        
        <p class="lead mb-4">Use our secure platform to transform your XML data and help expose the truth.</p>
        
        <form action="/submit-theory" method="post">
            <div class="form-group editor-container">
                <label for="xml-editor">XML Content:</label>
                <textarea id="xml-editor" name="xml_content" class="form-control"><?php echo htmlspecialchars($default_xml); ?></textarea>
                <small class="form-text text-muted">Your structured information in XML format.</small>
            </div>
            
            <div class="form-group">
                <label for="xslt_editor">XSLT Transformation:</label>
                <textarea id="xslt_editor" name="xslt_content" class="form-control" rows="10"
                placeholder="Enter your XSLT here..."><?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:template match="/">
        <html>
            <head>
                <title>TruthSeeker Transformation</title>
                <style>
                    body {
                        background-color: #121212;
                        color: #31e884;
                        font-family: monospace;
                        padding: 20px;
                        max-width: 800px;
                        margin: 0 auto;
                    }
                    .content {
                        background-color: rgba(30, 30, 46, 0.8);
                        border: 1px solid #31e884;
                        padding: 20px;
                        margin-top: 20px;
                        border-radius: 5px;
                    }
                    .article-title {
                        font-size: 18px; 
                        font-weight: bold;
                        color: #31e884;
                    }
                    .metadata {
                        color: #aaa;
                        font-size: 14px;
                        margin-top: 5px;
                    }
                    .paragraph {
                        margin: 10px 0;
                    }
                </style>
            </head>
            <body>
                <h1>Article Transformation</h1>
                
                <div class="content">
                    <!-- Extraction du titre -->
                    <div class="article-title">
                        <xsl:value-of select="/article/title"/>
                    </div>
                    
                    <!-- Extraction des métadonnées -->
                    <div class="metadata">
                        By <xsl:value-of select="/article/author"/> • 
                        <xsl:value-of select="/article/date"/>
                    </div>
                    
                    <hr style="border: none; border-top: 1px dotted #31e884; margin: 20px 0;"/>
                    
                    <!-- Contenu de l'article -->
                    <div class="article-content">
                        <xsl:for-each select="/article/content/paragraph">
                            <div class="paragraph">
                                <xsl:value-of select="."/>
                            </div>
                        </xsl:for-each>
                    </div>
                </div>
            </body>
        </html>
    </xsl:template>
</xsl:stylesheet></textarea>
                <small class="form-text text-muted">Define how your article should be transformed and displayed.</small>
            </div>
            
            <div class="text-center mt-4 mb-5">
                <button type="submit" class="btn btn-primary btn-lg">Transform & Submit</button>
            </div>
        </form>
        
        <div class="card mb-5">
            <div class="card-body">
                <h5 class="card-title">Advanced XSLT Features</h5>
                <p class="card-text">
                    XSLT is a powerful language that can access various resources for transformation.
                    You can use functions like <code>document()</code> to include external content in your transformations.
                </p>
                <div class="alert alert-info">
                    <strong>Tip:</strong> Our server processes these transformations securely, but always ensure your XSLT follows best practices.
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>TruthSeeker</h3>
                    <p>Independent Investigative Journalism</p>
                </div>
                <div class="col-md-6 text-md-right">
                    <p>Server Side Training With Phreaks 2600- By <a href="https://felix-billieres.gitbook.io/v2" target="_blank" style="color: #31e884; text-decoration: underline;">Elliot Belt</a> </p>
                    <p><small>Explorez les vulnérabilités XSLT pour accéder aux fichiers sensibles</small></p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.62.0/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.62.0/mode/xml/xml.min.js"></script>
    
    <script>
        // Initialize XML editor
        var xmlEditor = CodeMirror.fromTextArea(document.getElementById('xml-editor'), {
            mode: 'xml',
            lineNumbers: true,
            lineWrapping: true
        });
        
        // Initialize XSLT editor
        var xsltEditor = CodeMirror.fromTextArea(document.getElementById('xslt_editor'), {
            mode: 'xml',
            lineNumbers: true,
            lineWrapping: true
        });
    </script>
</body>
</html> 