<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - TruthSeeker</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Special+Elite&family=Rajdhani:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Rajdhani', sans-serif;
            line-height: 1.6;
            color: #e0e0e0;
            background-color: #121212;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(37, 206, 116, 0.05) 0%, transparent 70%),
                url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23203354' fill-opacity='0.1'%3E%3Cpath d='M50 50c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10s-10-4.477-10-10 4.477-10 10-10zM10 10c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10S0 25.523 0 20s4.477-10 10-10zm10 8c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm40 40c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
        .navbar {
            background-color: #1a1a2e;
            border-bottom: 1px solid #31e884;
            box-shadow: 0 2px 20px rgba(49, 232, 132, 0.2);
        }
        .navbar-brand {
            font-weight: bold;
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 1px;
            text-shadow: 0 0 5px rgba(49, 232, 132, 0.7);
            color: #31e884 !important;
        }
        .footer {
            background-color: #1a1a2e;
            border-top: 1px solid #31e884;
            color: white;
            padding: 2rem 0;
            margin-top: 3rem;
            box-shadow: 0 -2px 20px rgba(49, 232, 132, 0.2);
        }
        .truth-symbol {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 100px;
            height: 100px;
            opacity: 0.2;
            z-index: 0;
        }
        .truth-symbol:before, .truth-symbol:after {
            content: "";
            position: absolute;
            background-color: #31e884;
        }
        .truth-symbol:before {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            top: 20px;
            left: 20px;
            box-shadow: 0 0 20px #31e884;
        }
        .truth-symbol:after {
            width: 80px;
            height: 2px;
            top: 50px;
            left: 10px;
            box-shadow: 0 0 10px #31e884;
            transform: rotate(45deg);
        }
        @keyframes glow {
            0% { text-shadow: 0 0 5px rgba(49, 232, 132, 0.7); }
            50% { text-shadow: 0 0 20px rgba(49, 232, 132, 1); }
            100% { text-shadow: 0 0 5px rgba(49, 232, 132, 0.7); }
        }
        .navbar-brand {
            animation: glow 2s infinite;
        }
        h1, h2, h3, h4, h5 {
            color: #31e884;
            font-family: 'Special Elite', cursive;
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.4);
            background-color: rgba(30, 30, 46, 0.8);
            border: 1px solid rgba(49, 232, 132, 0.2);
            transition: all 0.3s ease;
            border-radius: 10px;
            overflow: hidden;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(49, 232, 132, 0.2);
            border-color: rgba(49, 232, 132, 0.5);
        }
        .card-title {
            color: #31e884;
            font-family: 'Orbitron', sans-serif;
        }
        .nav-link {
            position: relative;
            color: #e0e0e0 !important;
            transition: all 0.3s ease;
        }
        .nav-link:hover, .nav-link.active {
            color: #31e884 !important;
        }
        .nav-link:before {
            content: "";
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #31e884;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        .nav-link:hover:before, .nav-link.active:before {
            visibility: visible;
            width: 100%;
        }
        em {
            color: #31e884;
            font-style: normal;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="truth-symbol"></div>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="/">TruthSeeker</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/articles">Articles</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/submit-theory">Submit Theory</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="/about">About</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4">About TruthSeeker</h1>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-body">
                        <h3 class="card-title">Our Mission</h3>
                        <p class="card-text">
                            TruthSeeker was founded by a group of independent journalists and technology experts determined to create a platform where whistleblowers, researchers, and citizen journalists can safely publish information that the public deserves to know.
                        </p>
                        <p class="card-text">
                            We believe in transparency, accountability, and the power of information to create positive change in society. Our platform is designed to protect those who take risks to bring important information to light.
                        </p>
                    </div>
                </div>
                
                <div class="card mb-4">
                    <div class="card-body">
                        <h3 class="card-title">Our Technology</h3>
                        <p class="card-text">
                            TruthSeeker uses XML (eXtensible Markup Language) and XSLT (XSL Transformations) to process and publish information. This approach allows for structured data storage and flexible presentation.
                        </p>
                        <p class="card-text">
                            Our XML/XSLT transformation engine is built on secure foundations, designed to protect both the integrity of information and the identity of contributors.
                        </p>
                        <p class="card-text">
                            <em>Some technical details: Our server stores sensitive information in protected directories, ensuring data security and compartmentalization.</em>
                        </p>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h3 class="card-title">Contact Us</h3>
                        <p class="card-text">
                            For secure communications, please use our encrypted channels:
                        </p>
                        <ul>
                            <li>SecureDrop: available through our .onion address</li>
                            <li>PGP-encrypted email: contact@truthseeker-example.org</li>
                        </ul>
                        <p class="card-text">
                            <strong>Public Key Fingerprint:</strong><br>
                            2B3C 4D5E 6F7G 8H9I 0J1K 2L3M 4N5O 6P7Q
                        </p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title">Disclaimer</h3>
                        <p class="card-text">
                            TruthSeeker is committed to publishing accurate and reliable information. However, we cannot guarantee the absolute accuracy of all submitted content.
                        </p>
                        <p class="card-text">
                            Contributors are responsible for ensuring that their submissions do not violate applicable laws or compromise legitimate national security interests.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>TruthSeeker</h3>
                    <p>Independent Investigative Journalism</p>
                </div>
                <div class="col-md-6 text-md-right">
                <p>Server Side Training With Phreaks 2600- By <a href="https://felix-billieres.gitbook.io/v2" target="_blank" style="color: #31e884; text-decoration: underline;">Elliot Belt</a> </p>

                </div>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 