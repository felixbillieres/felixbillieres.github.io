# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-

# from flask import Flask, request, render_template, redirect, url_for, flash
# import lxml.etree as ET
# import os
# import tempfile
# import secrets
# import io

# app = Flask(__name__)
# app.secret_key = secrets.token_hex(16)

# # Configuration
# FLAG_PATH = "/flag.txt"
# DEFAULT_XML = """<?xml version="1.0" encoding="UTF-8"?>
# <article>
#     <title>The Truth About Government Secrets</title>
#     <author>Anonymous Researcher</author>
#     <date>2023-09-15</date>
#     <content>
#         <paragraph>Our investigations have uncovered disturbing evidence about covert operations.</paragraph>
#         <paragraph>Multiple sources confirm unauthorized surveillance programs targeting civilians.</paragraph>
#         <paragraph>Documents suggest involvement of high-ranking officials in the cover-up.</paragraph>
#     </content>
# </article>"""

# # Assurez-vous que le FLAG existe pour le CTF
# if not os.path.exists("/var/flags"):
#     os.makedirs("/var/flags")
    
# with open(FLAG_PATH, "w") as f:
#     f.write("FLAG{X5LT_1nJ3ct10n_r3v34l5_th3_1llum1n4t1}")

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/articles')
# def articles():
#     return render_template('articles.html')

# @app.route('/submit-theory', methods=['GET', 'POST'])
# def submit_theory():
#     if request.method == 'GET':
#         return render_template('submit_theory.html', default_xml=DEFAULT_XML)
    
#     if request.method == 'POST':
#         xml_content = request.form.get('xml_content', '')
#         xslt_content = request.form.get('xslt_content', '')
        
#         if not xml_content or not xslt_content:
#             flash('Please provide both XML and XSLT content', 'danger')
#             return render_template('submit_theory.html', default_xml=xml_content or DEFAULT_XML, xslt_content=xslt_content)
            
#         try:
#             # Préparer les données XML et XSLT
#             xml_bytes = xml_content.encode('utf-8')
#             xslt_bytes = xslt_content.encode('utf-8')
            
#             # Créer un résolveur d'URI personnalisé
#             class CustomResolver(ET.Resolver):
#                 def resolve(self, url, id, context):
#                     # Si l'URL commence par '/', considérer comme un chemin absolu
#                     if url.startswith('/'):
#                         return self.resolve_filename(url, context)
#                     return None
            
#             # Créer un parser avec le résolveur personnalisé
#             parser = ET.XMLParser()
#             resolver = CustomResolver()
#             parser.resolvers.add(resolver)
            
#             # Utiliser le parser pour les deux documents
#             xml_doc = ET.parse(io.BytesIO(xml_bytes))
#             xslt_doc = ET.parse(io.BytesIO(xslt_bytes), parser)
            
#             # Créer le transformateur
#             transform = ET.XSLT(xslt_doc)
            
#             # Appliquer la transformation
#             result = transform(xml_doc)
            
#             return render_template('result.html', result=str(result))
        
#         except Exception as e:
#             flash(f'Transformation error: {str(e)}', 'danger')
#             return render_template('submit_theory.html', default_xml=xml_content, xslt_content=xslt_content)

# @app.route('/about')
# def about():
#     return render_template('about.html')

# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0', port=5000) 