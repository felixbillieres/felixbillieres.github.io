<?php
// Configuration
$flag_path = __DIR__ . "/flag.txt";

// Créer le flag pour le CTF
if (!file_exists($flag_path)) {
    file_put_contents($flag_path, "PHREAKS{X5LT_1nJ3ct10n_r3v34l5_th3_1llum1n4t1}");
    // S'assurer que le fichier est lisible par tous
    chmod($flag_path, 0644);
    // Afficher un message debug (à supprimer en production)
    error_log("Flag file created at: " . $flag_path);
}

// Ajouter une info de debug dans la page
$flag_debug = "Flag status: " . (file_exists($flag_path) ? "Exists" : "Missing") . 
              " | Readable: " . (is_readable($flag_path) ? "Yes" : "No") .
              " | Size: " . (file_exists($flag_path) ? filesize($flag_path) : "N/A") . " bytes" .
              " | Content: " . (file_exists($flag_path) && is_readable($flag_path) ? file_get_contents($flag_path) : "Cannot read");
error_log($flag_debug);

// Gestion des messages flash
session_start();
$flash_messages = [];
if (isset($_SESSION['flash'])) {
    $flash_messages = $_SESSION['flash'];
    unset($_SESSION['flash']);
}

// XML par défaut
$default_xml = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<article>
    <title>The Truth About Government Secrets</title>
    <author>Anonymous Researcher</author>
    <date>2023-09-15</date>
    <content>
        <paragraph>Our investigations have uncovered disturbing evidence about covert operations.</paragraph>
        <paragraph>Multiple sources confirm unauthorized surveillance programs targeting civilians.</paragraph>
        <paragraph>Documents suggest involvement of high-ranking officials in the cover-up.</paragraph>
    </content>
</article>
XML;

// Fonction pour ajouter un message flash
function add_flash($type, $message) {
    if (!isset($_SESSION['flash'])) {
        $_SESSION['flash'] = [];
    }
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

// Routage simple
$route = $_SERVER['REQUEST_URI'];

// Traitement de la soumission du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $route === '/submit-theory') {
    $xml_content = $_POST['xml_content'] ?? '';
    $xslt_content = $_POST['xslt_content'] ?? '';
    
    if (empty($xml_content) || empty($xslt_content)) {
        add_flash('danger', 'Please provide both XML and XSLT content');
        header('Location: /submit-theory');
        exit;
    }
    
    try {
        // Créer les objets DOMDocument
        $xml = new DOMDocument();
        $xml->loadXML($xml_content);
        
        $xsl = new DOMDocument();
        $xsl->loadXML($xslt_content);
        
        // Créer le processeur XSLT
        $proc = new XSLTProcessor();
        $proc->importStylesheet($xsl);
        
        // Effectuer la transformation
        $result = $proc->transformToXML($xml);
        
        // Afficher la page de résultat
        include 'templates/result.php';
        exit;
    } catch (Exception $e) {
        add_flash('danger', 'Transformation error: ' . $e->getMessage());
        header('Location: /submit-theory');
        exit;
    }
}

// Routes
switch ($route) {
    case '/':
    case '/index':
        include 'templates/index.php';
        break;
    
    case '/articles':
        include 'templates/articles.php';
        break;
    
    case '/submit-theory':
        include 'templates/submit_theory.php';
        break;
    
    case '/about':
        include 'templates/about.php';
        break;
    
    default:
        header("HTTP/1.0 404 Not Found");
        echo "<h1>404 Not Found</h1>";
        break;
}
?> 