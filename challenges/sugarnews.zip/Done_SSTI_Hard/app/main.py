# from flask import Flask, render_template as flask_render_template, request, jsonify
# import re
# import os

# app = Flask(__name__)

# class SecurityFilter:
#     @staticmethod
#     def validate(template_string):
#         blacklist = [
#             '.',
#             '(',
#             ')',
#             'import',
#             'subprocess',
#             'system'
#         ]
        
#         if '${' in template_string:
#             for word in blacklist:
#                 if word in template_string:
#                     raise Exception("Forbidden character detected")
        
#         return template_string

# class FreeMarkerSimulator:
#     @staticmethod
#     def render(template_string, data):
#         try:
#             # Remplacement des variables simples
#             result = template_string
#             for key, value in data.items():
#                 result = result.replace('${' + key + '}', str(value))
            
#             # Support des expressions eval
#             if '?eval' in result:
#                 expr = re.search(r'\${(.*?)\?eval}', result)
#                 if expr:
#                     cmd = expr.group(1).strip('"\'')
#                     # Exécution réelle de la commande
#                     result = os.popen(cmd).read()
#             return result
#         except Exception as e:
#             return str(e)

# @app.route('/')
# def index():
#     return flask_render_template('dashboard.html')

# @app.route('/api/render', methods=['POST'])
# def render_template_api():
#     try:
#         template_string = request.json.get('template', '')
#         SecurityFilter.validate(template_string)
        
#         result = FreeMarkerSimulator.render(template_string, {
#             'company': 'ACME Corp',
#             'date': '2024-03-21',
#             'department': 'Engineering'
#         })
        
#         return jsonify({'result': result})
#     except Exception as e:
#         return jsonify({'error': str(e)}), 400

# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=8080, debug=True)

from flask import Flask, render_template as flask_render_template, request, jsonify
import re
import subprocess
import html
import shlex

app = Flask(__name__)

class SecurityFilter:
    @staticmethod
    def validate(template):
        blacklist = [
            r'freemarker\.template\.utility\.Execute',
            r'Runtime',
            r'ProcessBuilder',
            r'javax\.script',
            r';',
            r'\|\|',
            r'&',
            r'>',
            r'<',
            r'\$\{.*?system.*?\}',
            r'\$\{.*?exec.*?\}',
            r'\$\{.*?Process.*?\}',
            r'\.txt',  
            r'\.[a-zA-Z0-9]'  
        ]
        
        for pattern in blacklist:
            if re.search(pattern, template, re.IGNORECASE):
                raise ValueError("The Sugar Patrol's Anti-Cheating System blocked suspicious pattern!")
        
        return template

class FreeMarkerSimulator:
    @staticmethod
    def render(template_string, data):
        try:
            result = template_string
            for key, value in data.items():
                result = result.replace('${' + key + '}', str(value))
            
            if '?eval' in result:
                expr = re.search(r'\${(.*?)\?eval}', result)
                if expr:
                    cmd = expr.group(1).strip('"\'')
                    cmd_parts = shlex.split(cmd)
                    
                    allowed_commands = ['ls', 'pwd', 'whoami', 'id', 'head']
                    if cmd_parts[0] not in allowed_commands:
                        raise ValueError("Commande non autorisée")
                    
                    if cmd_parts[0] == 'head' and len(cmd_parts) > 1:
                        if not cmd_parts[1].startswith('/'):
                            cmd_parts[1] = '/' + cmd_parts[1]
                    
                    output = subprocess.check_output(
                        cmd,  # Utiliser la commande complète au lieu de cmd_parts
                        shell=True,  # Activer shell=True pour l'interprétation des wildcards
                        stderr=subprocess.STDOUT,
                        timeout=1,
                        universal_newlines=True
                    )[:200]
                    return html.escape(output)
            return result
        except Exception as e:
            return str(e)

@app.route('/')
def index():
    return flask_render_template('dashboard.html')

@app.route('/api/render', methods=['POST'])
def render_template_api():
    try:
        template = request.json.get('template', '')
        SecurityFilter.validate(template)
        result = FreeMarkerSimulator.render(template, {
            'company': 'CandyShell 🍬',
            'date': '2024-03-21',
            'department': 'Sécurité Phreaks'
        })
        return jsonify({'result': result})
    except ValueError as e:
        return jsonify({'error': f"🚨 WAF BLOCKED: {str(e)}"}), 403
    except Exception as e:
        return jsonify({'error': f"Erreur interne: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False)