from flask import Flask, request, send_file, render_template_string
import pdfkit
import tempfile

app = Flask(__name__)

@app.route('/')
def index():
    return '''
    <!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>ScamPDF.io - Disrupting The PDF Industry</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;500;700;900&family=Comic+Neue:wght@700&display=swap');
        
        :root {
            --primary: #00C4FF;
            --secondary: #FF5EDF;
            --accent: #7DE2D1;
            --dark: #2A2356;
            --light: #F9FAFF;
            --success: #36E2B4;
            --warning: #FFCB47;
            --danger: #FF6B6B;
            --gradient: linear-gradient(135deg, var(--primary), var(--secondary));
            --shadow: 0 8px 30px rgba(0, 196, 255, 0.25);
            --card-shadow: 0 15px 35px rgba(42, 35, 86, 0.1), 0 5px 15px rgba(0, 0, 0, 0.07);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55); /* Transition exagérément élastique */
        }

        body {
            font-family: 'Montserrat', 'Helvetica Neue', sans-serif;
            background: #f5f8ff;
            color: var(--dark);
            min-height: 100vh;
            padding: 0;
            margin: 0;
            overflow-x: hidden;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(0, 196, 255, 0.05) 0%, transparent 20%),
                radial-gradient(circle at 90% 80%, rgba(255, 94, 223, 0.05) 0%, transparent 20%),
                radial-gradient(circle at 50% 50%, rgba(125, 226, 209, 0.05) 0%, transparent 30%);
        }

        .confetti {
            position: fixed;
            width: 10px;
            height: 10px;
            background-color: var(--primary);
            opacity: 0.8;
            top: -10px;
            z-index: -1;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem 2rem;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.05);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .logo {
            font-weight: 900;
            font-size: 1.5rem;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logo span {
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            position: relative;
        }

        .logo span::after {
            content: "BETA";
            position: absolute;
            top: -8px;
            right: -30px;
            font-size: 0.6rem;
            background: var(--warning);
            color: var(--dark);
            padding: 2px 4px;
            border-radius: 4px;
            font-weight: 700;
            transform: rotate(15deg);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: rotate(15deg) scale(1); }
            50% { transform: rotate(15deg) scale(1.1); }
        }

        .nav-links {
            display: flex;
            gap: 2rem;
        }

        .nav-link {
            text-decoration: none;
            color: var(--dark);
            font-weight: 500;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            position: relative;
            padding: 0.5rem 0;
        }

        .nav-link::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--gradient);
            transition: width 0.3s;
        }

        .nav-link:hover::after {
            width: 100%;
        }

        .cta-button {
            background: var(--gradient);
            color: white;
            border: none;
            padding: 0.8rem 1.8rem;
            border-radius: 50px;
            font-weight: 700;
            font-size: 0.9rem;
            cursor: pointer;
            box-shadow: var(--shadow);
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .cta-button:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 15px 30px rgba(0, 196, 255, 0.4);
        }

        .hero {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 5rem 2rem 3rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .hero h1 {
            font-size: 3.5rem;
            font-weight: 900;
            margin-bottom: 1.5rem;
            line-height: 1.2;
            background: linear-gradient(45deg, var(--dark), var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero h1 span {
            display: block;
            font-family: 'Comic Neue', cursive;
            font-weight: 700;
            font-size: 1.5rem;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transform: rotate(-2deg);
            margin-bottom: 0.5rem;
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 800px;
            color: #636B83;
            margin-bottom: 3rem;
            line-height: 1.6;
        }

        .container {
            max-width: 800px;
            margin: 0 auto 5rem;
            background: white;
            padding: 3rem;
            border-radius: 20px;
            box-shadow: var(--card-shadow);
            position: relative;
            overflow: hidden;
        }

        .container::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 10px;
            background: var(--gradient);
        }

        .quote-bg {
            position: absolute;
            font-size: 20rem;
            opacity: 0.02;
            top: -5rem;
            right: -5rem;
            font-family: 'Comic Neue', cursive;
            color: var(--dark);
            z-index: 0;
        }

        .form-group {
            margin: 2rem 0;
            position: relative;
            z-index: 1;
        }

        .input-wrapper {
            position: relative;
            margin: 2rem 0;
        }

        .input-label {
            position: absolute;
            left: 1.2rem;
            top: -10px;
            background: white;
            padding: 0 0.5rem;
            font-size: 0.9rem;
            color: var(--primary);
            font-weight: 600;
        }

        input[type="text"] {
            width: 100%;
            padding: 1.4rem 1.2rem;
            border: 2px solid #E1E8F5;
            border-radius: 12px;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.9);
            color: var(--dark);
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        input[type="text"]:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(0, 196, 255, 0.1), inset 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        input[type="text"]::placeholder {
            color: #B8C2D8;
            font-style: italic;
        }

        button {
            display: block;
            width: 100%;
            padding: 1.4rem;
            background: var(--gradient);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.2rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.5s ease; /* Transition lente et inutile */
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow);
            z-index: 1;
        }

        button::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transform: translateX(-100%);
        }

        button:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 15px 30px rgba(0, 196, 255, 0.3);
        }

        button:hover::after {
            transform: translateX(100%);
            transition: transform 0.8s ease;
        }

        button i {
            margin-right: 0.8rem;
            font-size: 1.4rem;
        }

        .loading {
            display: none;
            text-align: center;
            margin: 3rem 0;
            position: relative;
            z-index: 1;
        }

        .loading p {
            margin-top: 1rem;
            font-weight: 600;
            color: var(--primary);
            font-size: 1.2rem;
        }

        .spinner {
            width: 60px;
            height: 60px;
            margin: 0 auto;
            border: 4px solid rgba(0, 196, 255, 0.1);
            border-top: 4px solid var(--primary);
            border-radius: 50%;
            animation: spin 1.5s cubic-bezier(0.68, -0.55, 0.265, 1.55) infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(720deg); } /* Spin exagéré */
        }

        .features {
            display: flex;
            justify-content: space-between;
            margin-top: 3rem;
            flex-wrap: wrap;
            gap: 1.5rem;
        }

        .feature {
            flex: 1 0 30%;
            min-width: 200px;
            background: rgba(255, 255, 255, 0.8);
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid #E1E8F5;
        }

        .feature i {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--primary);
            background: rgba(0, 196, 255, 0.1);
            width: 4rem;
            height: 4rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            margin: 0 auto 1rem;
        }

        .feature h3 {
            font-size: 1.2rem;
            margin-bottom: 0.5rem;
            color: var(--dark);
        }

        .feature p {
            font-size: 0.9rem;
            color: #636B83;
        }

        .testimonials {
            margin-top: 4rem;
            position: relative;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 12px;
            border: 1px solid #E1E8F5;
        }

        .testimonial {
            text-align: center;
            padding: 1rem;
        }

        .testimonial-text {
            font-size: 1.1rem;
            font-style: italic;
            color: #636B83;
            margin-bottom: 1.5rem;
            position: relative;
        }

        .testimonial-text::before,
        .testimonial-text::after {
            content: '"';
            font-size: 3rem;
            color: rgba(0, 196, 255, 0.2);
            position: absolute;
            font-family: 'Comic Neue', cursive;
        }

        .testimonial-text::before {
            top: -1.5rem;
            left: -1rem;
        }

        .testimonial-text::after {
            bottom: -2.5rem;
            right: -1rem;
        }

        .testimonial-author {
            font-weight: 600;
            color: var(--dark);
        }

        .testimonial-role {
            font-size: 0.9rem;
            color: #B8C2D8;
        }

        .security-badges {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 3rem;
            flex-wrap: wrap;
        }

        .badge {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.6rem 1rem;
            background: white;
            border-radius: 50px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
            border: 1px solid #E1E8F5;
        }

        .badge i {
            color: var(--success);
        }

        .badge span {
            font-size: 0.8rem;
            font-weight: 600;
            color: #636B83;
        }

        #pdfViewer {
            margin-top: 2rem;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: var(--card-shadow);
            position: relative;
            z-index: 1;
        }

        #pdfViewer iframe {
            border: none;
            width: 100%;
            height: 800px;
            background: white;
        }

        /* Corporate buzzwords floating */
        .buzzwords {
            position: absolute;
            opacity: 0.07;
            font-weight: 700;
            z-index: 0;
            color: var(--dark);
            font-size: 1.2rem;
            animation: float 20s infinite linear;
            white-space: nowrap;
        }

        @keyframes float {
            0% { transform: translateX(-100%) translateY(0) rotate(-5deg); }
            100% { transform: translateX(100vw) translateY(10px) rotate(5deg); }
        }

        /* Tooltip style */
        [data-tooltip] {
            position: relative;
        }

        [data-tooltip]::before,
        [data-tooltip]::after {
            position: absolute;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease;
            pointer-events: none;
            bottom: 100%;
        }

        [data-tooltip]::before {
            content: attr(data-tooltip);
            background: var(--dark);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            font-size: 0.8rem;
            white-space: nowrap;
            left: 50%;
            transform: translateX(-50%);
            margin-bottom: 10px;
        }

        [data-tooltip]::after {
            content: '';
            border: 8px solid transparent;
            border-top-color: var(--dark);
            left: 50%;
            transform: translateX(-50%);
            margin-bottom: -6px;
        }

        [data-tooltip]:hover::before,
        [data-tooltip]:hover::after {
            opacity: 1;
            visibility: visible;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .navbar {
                padding: 1rem;
            }
            
            .nav-links {
                display: none;
            }
            
            .hero {
                padding: 3rem 1rem 2rem;
            }
            
            .hero h1 {
                font-size: 2.5rem;
            }
            
            .hero p {
                font-size: 1rem;
            }
            
            .container {
                padding: 2rem;
                margin: 0 1rem 3rem;
            }
        }

        /* Glitchy effect for the startup vibe */
        .glitch {
            position: relative;
            animation: glitch 3s infinite;
        }

        @keyframes glitch {
            0% { transform: translate(0) }
            2% { transform: translate(-2px, 2px) }
            4% { transform: translate(2px, -2px) }
            6% { transform: translate(0) }
            100% { transform: translate(0) }
        }
    </style>
</head>
<body>
    <!-- Buzzwords floating in background -->
    <div class="buzzwords" style="top: 20%">DISRUPTION • INNOVATION • BLOCKCHAIN • AI • GROWTH HACKING</div>
    <div class="buzzwords" style="top: 40%; animation-delay: -5s">SYNERGY • LEVERAGE • PARADIGM SHIFT • ECOSYSTEM</div>
    <div class="buzzwords" style="top: 70%; animation-delay: -10s">AGILE • PIVOT • SCALABLE • MISSION-CRITICAL</div>

    <!-- Navbar -->
    <div class="navbar">
        <div class="logo">
            <i class="fas fa-file-pdf"></i>
            <span>ScamPDF.io</span>
        </div>
        <div class="nav-links">
            <a href="#" class="nav-link">Solutions</a>
            <a href="#" class="nav-link">Pricing</a>
            <a href="#" class="nav-link">Testimonials</a>
            <a href="#" class="nav-link">Blog</a>
        </div>
        <button class="cta-button">Get Started</button>
    </div>

    <!-- Hero section -->
    <div class="hero">
        <h1><span class="glitch">Transforming Web to PDF</span> The Future of "Business Plans" is Here</h1>
        <p>ScamPDF.io empowers entrepreneurs to rapidly prototype digital business models through our proprietary HTML-to-PDF conversion technology. Impress stakeholders with professionally rendered documentation of your "innovative" concepts.</p>
    </div>

    <div class="container">
        <div class="quote-bg">"</div>
        <h1 class="form-title" style="text-align: center; margin-bottom: 2rem; font-size: 1.8rem;">Generate Your "Business Plan" PDF</h1>
        
        <div class="form-group">
            <form id="pdfForm">
                <div class="input-wrapper">
                    <span class="input-label">HTML Content</span>
                    <input type="text" id="url" name="url" 
                           placeholder="Paste any HTML here for instant conversion..." 
                           autocomplete="off">
                </div>
                <button type="submit" data-tooltip="100% Legit, Trust Us!">
                    <i class="fas fa-wand-magic-sparkles"></i> Generate Instant PDF
                </button>
            </form>
        </div>

        <div class="loading">
            <div class="spinner"></div>
            <p>Applying disruptive PDF algorithms...</p>
        </div>

        <div id="pdfViewer"></div>

        <!-- Features -->
        <div class="features">
            <div class="feature">
                <i class="fas fa-bolt"></i>
                <h3>Lightning Fast</h3>
                <p>Convert any HTML to PDF in milliseconds, beating industry standards by 500%*</p>
            </div>
            <div class="feature">
                <i class="fas fa-shield-alt"></i>
                <h3>Enterprise Security</h3>
                <p>Military-grade encryption** that ensures your business plans stay confidential</p>
            </div>
            <div class="feature">
                <i class="fas fa-magic"></i>
                <h3>AI-Enhanced</h3>
                <p>Our proprietary algorithms*** make your PDFs look professional and trustworthy</p>
            </div>
        </div>

        <!-- Testimonial -->
        <div class="testimonials">
            <div class="testimonial">
                <p class="testimonial-text">ScamPDF.io revolutionized my business strategy. I was able to secure $2M in funding with a PDF that took 10 seconds to create!</p>
                <p class="testimonial-author">John Legitman</p>
                <p class="testimonial-role">CEO of Definitely Real Company</p>
            </div>
        </div>

        <!-- Security badges -->
        <div class="security-badges">
            <div class="badge">
                <i class="fas fa-lock"></i>
                <span>256-bit Encryption</span>
            </div>
            <div class="badge">
                <i class="fas fa-check-circle"></i>
                <span>ISO 27001 Certified</span>
            </div>
            <div class="badge">
                <i class="fas fa-shield-alt"></i>
                <span>GDPR Compliant</span>
            </div>
        </div>

        <!-- Fine print -->
        <p style="font-size: 0.7rem; color: #B8C2D8; margin-top: 3rem; text-align: center;">
            * Speed claims not verified by any independent party<br>
            ** Encryption may or may not actually be implemented<br>
            *** No actual AI is used in this process
        </p>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
    <script src="/static/script.js"></script>

    <script>
        // Create floating confetti
        function createConfetti() {
            const confettiColors = ['#00C4FF', '#FF5EDF', '#7DE2D1', '#FFCB47'];
            const confetti = document.createElement('div');
            confetti.classList.add('confetti');
            confetti.style.left = Math.random() * 100 + 'vw';
            confetti.style.backgroundColor = confettiColors[Math.floor(Math.random() * confettiColors.length)];
            confetti.style.animation = `fall ${Math.random() * 3 + 2}s linear forwards`;
            document.body.appendChild(confetti);
            
            // Remove confetti after animation
            setTimeout(() => {
                confetti.remove();
            }, 5000);
        }
        
        // Add confetti animation
        setInterval(createConfetti, 300);
        
        // Add fall animation for confetti
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes fall {
                to {
                    transform: translateY(100vh) rotate(720deg);
                }
            }
        `;
        document.head.appendChild(style);
        
        // Form handling
        document.getElementById('pdfForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            document.querySelector('.loading').style.display = 'block';
            
            // Buzzword generator for loading message
            const buzzwords = [
                "Applying disruptive PDF algorithms...",
                "Leveraging blockchain for document integrity...",
                "Synergizing your content strategy...",
                "Optimizing stakeholder-ready deliverables...",
                "Implementing agile document solutions..."
            ];
            
            document.querySelector('.loading p').textContent = 
                buzzwords[Math.floor(Math.random() * buzzwords.length)];
            
            // Hide loading after API response in the actual script.js
        });
    </script>
</body>
</html>
    
    '''

@app.route('/generate-pdf', methods=['POST'])
def generate_pdf():
    try:
        html_content = request.json.get('url', '')
        
        # Template vulnérable qui injecte directement le contenu HTML
        template = f'''
        <html>
            <body>
                {html_content}
            </body>
        </html>
        '''
        
        # Configuration de wkhtmltopdf avec accès aux fichiers locaux activé
        options = {
            'enable-local-file-access': True,
            'quiet': True
        }
        
        # Génération du PDF
        temp_pdf = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
        pdfkit.from_string(template, temp_pdf.name, options=options)
        
        return send_file(temp_pdf.name, mimetype='application/pdf')
        
    except Exception as e:
        return str(e), 500

if __name__ == '__main__':
    app.run(debug=True) 