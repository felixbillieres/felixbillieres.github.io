<?php
// Protection basique pour éviter d'afficher des fichiers non XML
function isValidPostName($postName) {
    return preg_match('/^[a-zA-Z0-9_-]+$/', $postName) && 
           file_exists('./posts/' . $postName . '.xml');
}

// Récupérer le post demandé
$postName = isset($_GET['post']) ? $_GET['post'] : (isset($_POST['post']) ? $_POST['post'] : '');

if (!isValidPostName($postName)) {
    header("HTTP/1.0 404 Not Found");
    die("Article introuvable!");
}

$xmlFile = './posts/' . $postName . '.xml';

// VULNÉRABILITÉ: Utilisation de XSLT personnalisé si fourni
if (isset($_POST['custom_xslt']) && !empty($_POST['custom_xslt'])) {
    $xsltContent = $_POST['custom_xslt'];
    
    // Enregistrer temporairement le XSLT fourni
    $tempXsltFile = tempnam(sys_get_temp_dir(), 'ice_king_');
    file_put_contents($tempXsltFile, $xsltContent);
    
    // Configuration de la transformation XSLT
    $xml = new DOMDocument();
    $xml->load($xmlFile);
    
    $xslt = new DOMDocument();
    $xslt->load($tempXsltFile);
    
    // VULNÉRABILITÉ: Permettre des fonctions PHP
    $proc = new XSLTProcessor();
    $proc->registerPHPFunctions(); // Permet d'appeler n'importe quelle fonction PHP via XSLT!
    $proc->importStylesheet($xslt);
    
    // Transformer et afficher
    echo $proc->transformToXML($xml);
    
    // Nettoyage
    unlink($tempXsltFile);
    exit;
}

// Affichage normal avec le XSLT par défaut
$xml = new DOMDocument;
$xml->load($xmlFile);

$xsl = new DOMDocument;
$xsl->load('./xslt/default.xsl');

$proc = new XSLTProcessor();
$proc->importStylesheet($xsl);

header('Content-Type: text/html; charset=utf-8');
echo $proc->transformToXML($xml);
?> 