document.addEventListener('DOMContentLoaded', function() {
    // Bouton pour jouer la chanson du Roi des Glaces
    const singButton = document.getElementById('sing-button');
    const iceSong = document.getElementById('ice-king-song');
    
    if (singButton && iceSong) {
        singButton.addEventListener('click', function() {
            if (iceSong.paused) {
                iceSong.play();
                singButton.textContent = "Arrête ce bruit horrible!";
                singButton.classList.add('singing');
            } else {
                iceSong.pause();
                iceSong.currentTime = 0;
                singButton.textContent = "Écoute le Roi des Glaces chanter!";
                singButton.classList.remove('singing');
            }
        });
    }
    
    // Animation du texte qui gèle progressivement
    setTimeout(function() {
        const paragraphs = document.querySelectorAll('p');
        paragraphs.forEach(p => {
            p.classList.add('freezing');
        });
    }, 30000); // Le texte commence à geler après 30 secondes
    
    // Animation de givre sur les images au survol
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.addEventListener('mouseenter', function() {
            img.style.filter = 'brightness(1.2) drop-shadow(0 0 8px #4fc3f7)';
        });
        img.addEventListener('mouseleave', function() {
            img.style.filter = '';
        });
    });
    
    // Création des flocons de neige
    createSnowflakes();
    
    // Effet sur les titres du blog
    const titles = document.querySelectorAll('h1, h2');
    titles.forEach(title => {
        title.addEventListener('mouseover', () => {
            title.style.transform = 'scale(1.03) rotate(-1deg)';
            title.style.transition = 'transform 0.3s ease';
        });
        title.addEventListener('mouseout', () => {
            title.style.transform = '';
        });
    });
    
    // Effet cristallisant sur les cartes d'articles
    const cards = document.querySelectorAll('.post-card');
    cards.forEach(card => {
        card.addEventListener('click', function(e) {
            if (e.target.tagName !== 'A') {
                addIceEffect(this);
            }
        });
    });
    
    // Création de l'arrière-plan glacé
    createFrozenBackground();
});

// Crée des flocons de neige qui tombent
function createSnowflakes() {
    const snowflakes = ['❄', '❅', '❆', '✻', '✼', '❉'];
    const container = document.body;
    
    for (let i = 0; i < 30; i++) {
        const snowflake = document.createElement('div');
        snowflake.className = 'ice-flake';
        snowflake.textContent = snowflakes[Math.floor(Math.random() * snowflakes.length)];
        snowflake.style.left = `${Math.random() * 100}vw`;
        snowflake.style.opacity = Math.random() * 0.7 + 0.3;
        snowflake.style.fontSize = `${Math.random() * 20 + 10}px`;
        
        // Animation custom pour chaque flocon
        const duration = Math.random() * 15 + 10; // entre 10 et 25 secondes
        const delay = Math.random() * 10; // délai de départ aléatoire
        
        snowflake.style.animation = `snowfall ${duration}s linear ${delay}s infinite`;
        
        container.appendChild(snowflake);
    }
}

// Ajoute un effet de cristallisation quand on clique
function addIceEffect(element) {
    const iceOverlay = document.createElement('div');
    iceOverlay.className = 'ice-effect-overlay';
    iceOverlay.style.position = 'absolute';
    iceOverlay.style.top = '0';
    iceOverlay.style.left = '0';
    iceOverlay.style.right = '0';
    iceOverlay.style.bottom = '0';
    iceOverlay.style.backgroundColor = 'rgba(224, 247, 255, 0.7)';
    iceOverlay.style.zIndex = '2';
    iceOverlay.style.pointerEvents = 'none';
    iceOverlay.style.borderRadius = 'inherit';
    iceOverlay.style.opacity = '0';
    iceOverlay.style.transition = 'opacity 0.5s ease';
    
    element.style.position = 'relative';
    element.appendChild(iceOverlay);
    
    // Apparition progressive
    setTimeout(() => {
        iceOverlay.style.opacity = '0.7';
    }, 10);
    
    // Disparition après un moment
    setTimeout(() => {
        iceOverlay.style.opacity = '0';
        setTimeout(() => {
            element.removeChild(iceOverlay);
        }, 500);
    }, 1000);
}

// Fonction pour créer l'arrière-plan glacé avec étoiles et flocons
function createFrozenBackground() {
    // Création du conteneur principal pour les effets de neige
    const snowBg = document.createElement('div');
    snowBg.className = 'snow-bg';
    document.body.appendChild(snowBg);
    
    // Création des étoiles scintillantes (cristaux de glace éloignés)
    const starsLayer = document.createElement('div');
    starsLayer.className = 'snow-layer';
    snowBg.appendChild(starsLayer);
    
    // Ajouter 100 étoiles scintillantes
    for (let i = 0; i < 100; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        star.style.left = `${Math.random() * 100}%`;
        star.style.top = `${Math.random() * 100}%`;
        star.style.width = `${Math.random() * 3 + 1}px`;
        star.style.height = star.style.width;
        star.style.animationDelay = `${Math.random() * 5}s`;
        starsLayer.appendChild(star);
    }
    
    // Ajouter des flocons de neige plus grands et plus lents en arrière-plan
    const backgroundFlakes = ['❄', '❅', '❆', '✻', '✼', '•'];
    for (let i = 0; i < 30; i++) {
        const flake = document.createElement('div');
        flake.className = 'ice-flake background-flake';
        flake.textContent = backgroundFlakes[Math.floor(Math.random() * backgroundFlakes.length)];
        flake.style.left = `${Math.random() * 100}%`;
        flake.style.top = `${Math.random() * 50 - 50}%`; // Commencer au-dessus de l'écran
        flake.style.opacity = Math.random() * 0.3 + 0.1; // Plus transparent
        flake.style.fontSize = `${Math.random() * 30 + 20}px`; // Plus gros
        flake.style.filter = 'blur(2px)'; // Effet de flou pour l'impression de profondeur
        
        // Animation personnalisée
        const duration = Math.random() * 30 + 30; // 30-60 secondes (plus lent)
        flake.style.animation = `snowfall ${duration}s linear 0s infinite`;
        
        snowBg.appendChild(flake);
    }
}

// Ajoutez ces styles CSS pour les flocons d'arrière-plan spécifiques
document.addEventListener('DOMContentLoaded', function() {
    const style = document.createElement('style');
    style.textContent = `
        .background-flake {
            z-index: -2;
            filter: blur(2px);
            opacity: 0.2;
            color: #b3e5fc;
        }
        
        @keyframes gentle-drift {
            0% {
                transform: translateX(0);
            }
            50% {
                transform: translateX(20px);
            }
            100% {
                transform: translateX(0);
            }
        }
    `;
    document.head.appendChild(style);
}); 