<?php
// Liste des articles disponibles
$posts = array_diff(scandir('./posts'), array('..', '.'));
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Le Blog Glacé du Roi des Glaces</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="frost-container">
        <div class="frost-overlay"></div>
        <header>
            <h1>📝 Le Blog Glacé du Roi des Glaces 🧊</h1>
            <p class="subtitle">Mes pensées royales et glaciales pour tous mes sujets (et futures princesses)</p>
        </header>
        
        <main>
            <section class="ice-posts">
                <h2>🧊 Mes Articles Royaux 👑</h2>
                <div class="posts-list">
                <?php foreach($posts as $post): 
                    $postName = pathinfo($post, PATHINFO_FILENAME);
                    $xml = simplexml_load_file('./posts/' . $post);
                    $title = $xml->title;
                    $date = $xml->date;
                ?>
                    <div class="post-card">
                        <h3><?php echo htmlspecialchars($title); ?></h3>
                        <p class="date"><?php echo htmlspecialchars($date); ?></p>
                        <a href="view.php?post=<?php echo $postName; ?>" class="ice-button">Lire l'article</a>
                    </div>
                <?php endforeach; ?>
                </div>
            </section>
            
            <section class="ice-features">
                <h2>🎵 Mes Talents Cachés 🎤</h2>
                <button id="sing-button" class="ice-button large">Écoute le Roi des Glaces chanter!</button>
                <audio id="ice-king-song" src="assets/sounds/ice-king-song.mp3"></audio>
            </section>
            
            <section class="advanced-section">
                <h2>⚙️ Section Avancée (pour mes travaux royaux) ⚙️</h2>
                <form action="view.php" method="post" class="custom-xslt-form">
                    <p>Fournir un XSLT personnalisé pour afficher mes articles royaux:</p>
                    <textarea name="custom_xslt" placeholder="Colle ton XSLT ici..."></textarea>
                    <select name="post" class="ice-select">
                        <?php foreach($posts as $post): ?>
                            <option value="<?php echo pathinfo($post, PATHINFO_FILENAME); ?>">
                                <?php echo pathinfo($post, PATHINFO_FILENAME); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="ice-button">Transformer</button>
                </form>
            </section>
        </main>
        
        <footer>
            <p>© Royaume des Glaces - Tous droits gelés</p>
            <p class="small">Créé avec l'aide de Gunter 🐧</p>
        </footer>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html> 