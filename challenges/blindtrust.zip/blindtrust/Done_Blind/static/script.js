document.getElementById('pdfForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const userInput = document.getElementById('url').value;
    
    try {
        const response = await fetch('/generate-pdf', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: userInput })
        });
        
        const blob = await response.blob();
        const pdfUrl = URL.createObjectURL(blob);
        
        const viewer = document.getElementById('pdfViewer');
        viewer.innerHTML = `
            <iframe src="${pdfUrl}" width="100%" height="800px"></iframe>
        `;
    } catch (error) {
        console.error('Erreur:', error);
    }
});
