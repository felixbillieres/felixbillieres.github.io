from flask import Flask, request, send_file
import pdfkit
import tempfile
import requests

app = Flask(__name__)

@app.route('/')
def index():
    return '''
<!DOCTYPE html>
<html lang="fr" data-font-size="normal">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AccessiPDF - Blog & Générateur PDF Accessible</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --background: #f8fafc;
            --text: #1e293b;
            --card: #ffffff;
            --border: #e2e8f0;
            --success: #059669;
            font-size: 16px;
        }

        [data-font-size="large"] {
            font-size: 20px;
        }

        [data-font-size="xlarge"] {
            font-size: 24px;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --background: #0f172a;
                --text: #f8fafc;
                --card: #1e293b;
                --border: #334155;
            }
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: var(--background);
            color: var(--text);
            min-height: 100vh;
            padding: 2rem;
            line-height: 1.5;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            text-align: center;
            margin-bottom: 3rem;
        }

        h1 {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(45deg, #4f46e5, #2563eb);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: inline-block;
        }

        .subtitle {
            color: #64748b;
            font-size: 1.1rem;
        }

        .card {
            background: var(--card);
            padding: 2rem;
            border-radius: 1rem;
            border: 1px solid var(--border);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .card:hover {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        }

        .form-group {
            margin: 1.5rem 0;
        }

        .input-wrapper {
            position: relative;
        }

        input[type="text"], input[type="url"] {
            width: 100%;
            padding: 1rem 1rem 1rem 2.5rem;
            border: 2px solid var(--border);
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--card);
            color: var(--text);
        }

        input[type="text"]:focus, input[type="url"]:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
        }

        button {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 1rem 2rem;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
            justify-content: center;
            position: relative;
        }

        button:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
        }

        .loader {
            border: 4px solid rgba(255, 255, 255, 0.2);
            border-top: 4px solid white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
            display: none;
        }

        #pdfViewer {
            margin-top: 2rem;
            border: 2px solid var(--border);
            border-radius: 0.5rem;
            min-height: 500px;
            background: var(--card);
        }

        .error-message {
            color: #dc2626;
            padding: 1rem;
            margin-top: 1rem;
            background: #fee2e2;
            border-radius: 0.5rem;
            display: none;
        }

        .success-message {
            color: var(--success);
            padding: 1rem;
            margin-top: 1rem;
            background: #ecfdf5;
            border-radius: 0.5rem;
            display: none;
        }

        .settings {
            margin-top: 1.5rem;
            border-top: 1px solid var(--border);
            padding-top: 1.5rem;
        }

        .history-section {
            margin-top: 2rem;
        }

        .history-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            border: 1px solid var(--border);
            border-radius: 0.5rem;
            margin-bottom: 0.5rem;
        }

        .progress-bar {
            height: 4px;
            background: rgba(37, 99, 235, 0.1);
            border-radius: 2px;
            margin-top: 1rem;
            overflow: hidden;
            display: none;
        }

        .progress {
            height: 100%;
            background: var(--primary);
            width: 0%;
            transition: width 0.3s ease;
        }

        /* Nouveaux styles pour l'accessibilité */
        .skip-link {
            position: absolute;
            left: -10000px;
            top: auto;
            width: 1px;
            height: 1px;
            overflow: hidden;
        }

        .skip-link:focus {
            position: static;
            width: auto;
            height: auto;
            padding: 0.5rem;
            background: var(--card);
        }

        .main-grid {
            display: grid;
            grid-template-columns: 1fr 300px;
            gap: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .blog-content {
            max-width: 800px;
        }

        article {
            margin-bottom: 3rem;
            background: var(--card);
            padding: 2rem;
            border-radius: 1rem;
            border: 1px solid var(--border);
        }

        h2, h3 {
            margin-bottom: 1rem;
            color: var(--primary);
        }

        .article-meta {
            font-size: 0.9rem;
            color: #64748b;
            margin-bottom: 1rem;
        }

        .accessibility-sidebar {
            position: sticky;
            top: 2rem;
            height: fit-content;
            background: var(--card);
            padding: 1.5rem;
            border-radius: 1rem;
            border: 1px solid var(--border);
        }

        .contrast-switcher {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .font-size-controls {
            margin-bottom: 2rem;
        }
        
        .font-size-controls button {
            width: auto;
            padding: 0.5rem 1rem;
            margin-right: 0.5rem;
        }
        
        .contrast-switcher button {
            width: 100%;
        }
        
        .high-contrast {
            --background: #000000;
            --text: #ffffff;
            --card: #000000;
            --border: #ffffff;
            --primary: #ffff00;
            --primary-hover: #ffff99;
        }
        
        body.keyboard-nav :focus {
            outline: 3px solid var(--primary);
            outline-offset: 3px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
            .main-grid {
                grid-template-columns: 1fr;
            }
            
            .accessibility-sidebar {
                position: static;
            }
        }

        @media (max-width: 640px) {
            body {
                padding: 1rem;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            .card {
                padding: 1.5rem;
            }
        }
    </style>
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body>
    <a href="#main-content" class="skip-link">Aller au contenu principal</a>
    
    <div class="container">
        <header>
            <h1>AccessiPDF</h1>
            <p class="subtitle">Blog sur l'accessibilité numérique & Générateur PDF adapté</p>
        </header>

        <div class="main-grid">
            <main id="main-content" class="blog-content">
                <article aria-labelledby="article1-title">
                    <div class="article-meta">Publié le 12 mars 2024 • Lecture 5 min</div>
                    <h2 id="article1-title">Créer des PDF accessibles pour les malvoyants</h2>
                    <p>Les documents numériques doivent être conçus en pensant à l'accessibilité. Voici nos conseils :</p>
                    <ul>
                        <li>Utiliser une structure logique de titres</li>
                        <li>Ajouter des descriptions aux images</li>
                        <li>Choisir des polices lisibles</li>
                        <li>Assurer un contraste suffisant</li>
                    </ul>
                </article>

                <article aria-labelledby="article2-title">
                    <div class="article-meta">Publié le 10 mars 2024 • Lecture 8 min</div>
                    <h2 id="article2-title">Technologies d'assistance : guide pratique</h2>
                    <p>Découvrez comment les outils comme les lecteurs d'écran interagissent avec les PDF :</p>
                    <h3>Bonnes pratiques</h3>
                    <p>Structuration des documents, métadonnées, balisage sémantique...</p>
                </article>
                
                <div id="pdfViewer"></div>
            </main>

            <aside class="accessibility-sidebar">
                <div class="font-size-controls">
                    <h3>Taille du texte</h3>
                    <button onclick="document.documentElement.setAttribute('data-font-size', 'normal')">A</button>
                    <button onclick="document.documentElement.setAttribute('data-font-size', 'large')">A+</button>
                    <button onclick="document.documentElement.setAttribute('data-font-size', 'xlarge')">A++</button>
                </div>

                <div class="contrast-switcher">
                    <button onclick="document.body.classList.toggle('high-contrast')">Contraste élevé</button>
                </div>

                <div class="card">
                    <h3>Générer un PDF accessible</h3>
                    <form id="pdfForm">
                        <div class="input-wrapper">
                            <i class="input-icon" data-feather="link"></i>
                            <input type="url" id="url" name="url" 
                                   placeholder="https://exemple.com" 
                                   required
                                   pattern="https?://.+"
                                   aria-label="URL du site à convertir en PDF">
                        </div>

                        <div class="error-message" id="errorMessage" role="alert"></div>
                        <div class="success-message" id="successMessage" role="status"></div>
                        <div class="progress-bar" aria-hidden="true">
                            <div class="progress" id="progress"></div>
                        </div>

                        <button type="submit" id="submitBtn">
                            <span>Générer PDF</span>
                            <div class="loader" id="loader"></div>
                        </button>

                        <div class="settings">
                            <label>
                                <input type="checkbox" id="secureCheckbox">
                                Protéger le PDF avec mot de passe
                            </label>
                        </div>
                    </form>
                </div>

                <div class="card history-section">
                    <h3>Historique des conversions</h3>
                    <div id="historyList">
                        <div class="history-item">
                            <span>https://exemple.com</span>
                            <span>12/06/2023</span>
                        </div>
                    </div>
                </div>
            </aside>
        </div>
    </div>

    <script>
        feather.replace();
        
        // Fonctionnalités d'accessibilité
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                document.body.classList.add('keyboard-nav');
            }
        });

        document.addEventListener('click', () => {
            document.body.classList.remove('keyboard-nav');
        });

        document.getElementById('pdfForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const form = e.target;
            const submitBtn = document.getElementById('submitBtn');
            const loader = document.getElementById('loader');
            const progressBar = document.querySelector('.progress-bar');
            const progress = document.getElementById('progress');
            const errorMessage = document.getElementById('errorMessage');
            const successMessage = document.getElementById('successMessage');

            // Réinitialiser les messages
            errorMessage.style.display = 'none';
            successMessage.style.display = 'none';

            submitBtn.disabled = true;
            loader.style.display = 'inline-block';
            progressBar.style.display = 'block';

            // Simulation de progression
            let progressValue = 0;
            const progressInterval = setInterval(() => {
                progressValue += 10;
                progress.style.width = `${progressValue}%`;
                if(progressValue >= 100) clearInterval(progressInterval);
            }, 300);

            const userInput = document.getElementById('url').value;
            
            try {
                const response = await fetch('/generate-pdf', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ url: userInput })
                });
                
                if (!response.ok) {
                    throw new Error('Erreur lors de la génération du PDF');
                }
                
                const blob = await response.blob();
                const pdfUrl = URL.createObjectURL(blob);
                
                successMessage.style.display = 'block';
                successMessage.textContent = 'PDF généré avec succès !';
                
                const viewer = document.getElementById('pdfViewer');
                viewer.innerHTML = `
                    <iframe src="${pdfUrl}" width="100%" height="800px" title="Aperçu du PDF généré"></iframe>
                `;
                
                // Ajouter à l'historique
                const historyList = document.getElementById('historyList');
                const date = new Date().toLocaleDateString('fr-FR');
                const historyItem = document.createElement('div');
                historyItem.className = 'history-item';
                historyItem.innerHTML = `
                    <span>${userInput}</span>
                    <span>${date}</span>
                `;
                historyList.prepend(historyItem);
                
            } catch (error) {
                errorMessage.style.display = 'block';
                errorMessage.textContent = 'Erreur lors de la génération du PDF. Veuillez réessayer.';
                console.error('Erreur:', error);
            } finally {
                submitBtn.disabled = false;
                loader.style.display = 'none';
                progressBar.style.display = 'none';
                progress.style.width = '0%';
                clearInterval(progressInterval);
            }
        });
    </script>
</body>
</html>
    '''

@app.route('/generate-pdf', methods=['POST'])
def generate_pdf():
    try:
        url = request.json.get('url', '')

        # 🔥 Récupération du contenu HTML de l'URL cible
        response = requests.get(url, timeout=5)
        if response.status_code != 200:
            return "Erreur: Impossible d'accéder à l'URL", 400

        html_content = response.text  # Récupère le HTML du site cible

        # 🔥 Génération du PDF
        options = {
            'enable-local-file-access': True,
            'javascript-delay': 2000,  # Permet aux scripts de s'exécuter
            'enable-javascript': True,
            'quiet': True
        }

        temp_pdf = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
        pdfkit.from_string(html_content, temp_pdf.name, options=options)

        return send_file(temp_pdf.name, mimetype='application/pdf')

    except Exception as e:
        return str(e), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
